package hr.fer.kommre2.sse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@Service
public class SseService {
	private Logger log = LoggerFactory.getLogger(getClass());
	
	private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();

	public void addEmitter(SseEmitter emitter) {
		emitters.add(emitter);
		emitter.onCompletion(() -> emitters.remove(emitter));
		emitter.onTimeout(() -> emitters.remove(emitter));
		emitter.onError(t -> {
			emitters.remove(emitter);
			log.error("SSE emitter error", t);
		});
	}

	@Scheduled(fixedRate = 1000)
	public void sendEvents() {
		for (SseEmitter emitter : emitters) {
			try {
				emitter.send(System.currentTimeMillis());
			} catch (IOException e) {
				emitters.remove(emitter);
			}
		}
	}
}
